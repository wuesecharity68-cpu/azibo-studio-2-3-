# AZIBO STUDIO - Video Generator Setup Guide

This guide walks you through adding any video generator to AZIBO STUDIO.

## Quick Start

### Step 1: Add Generator in Admin Panel

1. Go to `/admin/ai-providers`
2. Click "Add New Generator"
3. Fill in the details:
   - **Generator ID**: `my-generator` (unique identifier)
   - **Generator Name**: Display name
   - **API Endpoint**: Your generator's API URL
   - **API Key**: Your authentication credentials
   - **Priority**: Lower number = higher priority (for failover)
   - **Credit Cost**: Cost per video (flexible - you set it)
   - **Enabled**: Toggle to activate

### Step 2: Configure Supported Features

Check which features your generator supports:
- Talking Animals
- Human Videos
- Image to Video
- Custom Styles

### Step 3: Create API Handler

Create `/app/api/generate-video/route.ts`:

```typescript
import { NextRequest, NextResponse } from 'next/server'
import { getGeneratorById } from '@/lib/video-generator-config'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, duration, style, generatorId } = body

    const generator = getGeneratorById(generatorId)
    if (!generator?.enabled) {
      return NextResponse.json(
        { error: 'Generator not available' },
        { status: 400 }
      )
    }

    // Call your generator's API
    const response = await fetch(generator.apiEndpoint!, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${generator.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        duration,
        style,
      }),
    })

    if (!response.ok) {
      throw new Error('Generator API failed')
    }

    const data = await response.json()
    
    return NextResponse.json({
      videoUrl: data.videoUrl || data.url,
      success: true,
    })
  } catch (error) {
    console.error('[v0] Video generation error:', error)
    return NextResponse.json(
      { error: 'Failed to generate video' },
      { status: 500 }
    )
  }
}
```

## Supported Video Generators

### Popular Options:

**OpenAI DALL-E Video**
- Website: https://openai.com
- Features: All types, custom styles
- API: https://api.openai.com/v1/videos
- Cost estimate: $0.50/video

**Synthesia**
- Website: https://www.synthesia.io
- Features: Talking humans with AI avatars
- API: https://api.synthesia.io/v1/videos
- Cost estimate: $0.75/video

**Runway ML**
- Website: https://runwayml.com
- Features: Video generation, editing, effects
- API: https://api.runwayml.com/v1/generate
- Cost estimate: $0.60/video

**HeyGen**
- Website: https://www.heygen.com
- Features: Talking avatar videos with speech
- API: https://api.heygen.com/v1/video_talks
- Cost estimate: $0.80/video

**Pika Labs**
- Website: https://www.pika.art
- Features: High-quality video generation
- API: https://api.pika.art/v1/generate
- Cost estimate: Variable

**Eleven Labs Video**
- Website: https://elevenlabs.io
- Features: Talking videos with AI voices
- API: https://api.elevenlabs.io/v1/generate_video
- Cost estimate: $0.90/video

**D-ID**
- Website: https://www.d-id.com
- Features: Talking head videos with AI
- API: https://api.d-id.com/talks
- Cost estimate: $0.70/video

**Loom**
- Website: https://www.loom.com
- Features: Screen recording and video creation
- API: https://www.loom.com/api
- Cost estimate: Built into plan

## Credit System (Flexible)

You control the credit cost for each generator. Examples:

```typescript
{
  id: 'openai-video',
  creditCost: 50,  // 50 credits per video
}

{
  id: 'synthesia',
  creditCost: 75,  // 75 credits per video
}

{
  id: 'runway',
  creditCost: 60,  // 60 credits per video
}
```

Users are automatically charged based on the generator's creditCost.

## Environment Variables

Store API keys securely:

```bash
# .env.local
OPENAI_API_KEY=sk-...
SYNTHESIA_API_KEY=...
RUNWAY_API_KEY=...
HEYGEN_API_KEY=...
```

Access in code:

```typescript
const apiKey = process.env[`${generatorId.toUpperCase()}_API_KEY`]
```

## Failover System

If a generator fails, the system automatically tries the next one:

1. Primary generator (priority: 1)
2. Secondary generator (priority: 2)
3. Tertiary generator (priority: 3)

Set priority in admin panel or code.

## Testing Your Integration

1. **Enable in Admin**:
   - Go to `/admin/ai-providers`
   - Enable your generator
   - Set it as priority 1

2. **Test Generation**:
   - Go to `/talking-animals` or `/human-videos`
   - Generate a video
   - Check console for errors
   - Verify video appears in player

3. **Verify Credits**:
   - Check that credits are deducted correctly
   - Verify transaction in admin analytics

## Troubleshooting

**Generator returns 401 Unauthorized**
- Check API key is correct
- Verify key hasn't expired
- Check API endpoint URL

**Generator returns 400 Bad Request**
- Verify request format matches API spec
- Check all required fields are included
- Check parameter types and values

**Videos not generating**
- Check generator is enabled in admin
- Verify available credits are sufficient
- Check API rate limits haven't been exceeded
- Review console logs for errors

**Failover not working**
- Verify backup generators are enabled
- Check priority numbers are set correctly
- Test each generator individually

## API Response Format

Your generator should return:

```json
{
  "videoUrl": "https://...",
  "duration": 30,
  "thumbnailUrl": "https://...",
  "status": "completed"
}
```

Map any differences in your handler:

```typescript
const data = await response.json()

// Map to standard format
const videoUrl = data.videoUrl || data.url || data.output
```

## Performance Tips

1. **Enable caching** - Cache generated videos for similar prompts
2. **Batch processing** - Queue multiple requests
3. **CDN delivery** - Use CDN for video delivery
4. **Compression** - Compress videos before delivery

## Security

- Never commit API keys to git
- Use environment variables for all secrets
- Rotate API keys regularly
- Rate limit API calls
- Validate user input before sending to generator
- Log all API calls for audit

## Support

For issues or questions:
1. Check `/docs/VIDEO_GENERATORS.md` for detailed info
2. Review admin panel configuration
3. Check console logs and error messages
4. Test with curl or Postman first
