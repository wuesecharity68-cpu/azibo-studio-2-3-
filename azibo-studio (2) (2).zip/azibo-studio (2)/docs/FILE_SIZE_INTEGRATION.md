# File Size Display Integration Guide

## Overview
The file size display feature is ready to use. Here's how to integrate it into your video generation pages.

## Step-by-Step Integration

### For `/app/talking-animals/page.tsx` and `/app/human-videos/page.tsx`:

#### 1. Import the storage utilities
```typescript
import { getFormattedFileSize } from '@/lib/storage-utils'
```

#### 2. Add state to track file size
```typescript
const [videoFileSize, setVideoFileSize] = useState<string>('')
```

#### 3. Get file size after video generation
```typescript
// After successful video generation
const storagePath = `videos/${user?.uid}/${generatedVideo.id}.mp4`
const formattedSize = await getFormattedFileSize(storagePath)
setVideoFileSize(formattedSize)
```

#### 4. Pass to VideoPlayer component
```typescript
<VideoPlayer
  videoUrl={generatedVideo.url}
  videoId={generatedVideo.id}
  fileSizeMB={videoFileSize}
  subscriptionPlan={profile?.subscriptionPlan || 'free'}
  onRegeneerate={() => setGeneratedVideo(null)}
  onDownload={async (addWatermark) => {
    // Download logic
  }}
  userRole={profile?.role || 'user'}
/>
```

## Storage Path Conventions

The storage path should follow your Firebase Storage structure. Common patterns:

- By user: `videos/{uid}/{videoId}.mp4`
- By type: `videos/talking-animals/{videoId}.mp4`
- Timestamped: `videos/{uid}/{timestamp}-{videoId}.mp4`

Adjust the `storagePath` variable based on your actual Firebase Storage organization.

## Error Handling

The `getFormattedFileSize()` function gracefully handles errors:
- Returns empty string if Firebase Storage is unavailable
- Returns empty string if file not found
- Returns empty string if metadata fetch fails

The Download button will display: `Download ()` if file size is empty, which is acceptable.

## File Size Format Examples

Output examples from the `formatBytes()` function:
- 512 bytes → `"512 Bytes"`
- 1536 bytes → `"1.5 KB"`
- 5242880 bytes → `"5 MB"`
- 1073741824 bytes → `"1 GB"`

The format is: `{number} {unit}` with decimal precision to 2 places.

## Async Loading

The file size fetch is asynchronous. Consider adding a loading state:

```typescript
const [loadingSize, setLoadingSize] = useState(false)

// When video is generated
setLoadingSize(true)
const size = await getFormattedFileSize(storagePath)
setVideoFileSize(size)
setLoadingSize(false)
```

## Display Examples

For a 12.5 MB video:

**Free User:**
- Button text: `Download (12.5 MB with Watermark)`
- Watermark notice: Shows

**Paid User:**
- Button text: `Download (12.5 MB)`
- Watermark notice: Hidden

---

## Next Steps

1. Update your video generation pages with the storage path
2. Test with actual video uploads to Firebase Storage
3. Verify file sizes display correctly on the Download button
4. Ensure watermark status displays appropriately based on subscription
