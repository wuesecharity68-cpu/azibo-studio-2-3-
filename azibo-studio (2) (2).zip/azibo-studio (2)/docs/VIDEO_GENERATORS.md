# Video Generator Configuration Guide

AZIBO STUDIO supports any video generation API. This guide explains how to add and configure video generators.

## Overview

The system is built to support multiple video generators with automatic failover. Each generator can have different features, credit costs, and priorities.

## Adding a Video Generator

### Step 1: Add to Admin Panel

Go to `/admin/ai-providers` and add a new video generator with:

- **Generator ID**: Unique identifier (e.g., `openai-gpt4-video`)
- **Generator Name**: Display name (e.g., `OpenAI GPT-4 Video`)
- **API Endpoint**: The API URL for the generator
- **API Key**: Your authentication credentials
- **Priority**: Lower number = higher priority (used for failover)
- **Credit Cost**: Cost per video generation (flexible)
- **Enabled**: Toggle to activate/deactivate
- **Supported Features**: Check which features this generator supports

### Step 2: Update Code Integration

Edit the video generation pages to call your generator:

```typescript
// app/talking-animals/page.tsx or app/human-videos/page.tsx

import { getActiveGenerators } from '@/lib/video-generator-config'

// Get the best available generator
const generators = getActiveGenerators()
const primaryGenerator = generators[0]

// Call your generator's API
const response = await fetch(`/api/generate-video`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    prompt: formData.prompt,
    duration: formData.duration,
    generatorId: primaryGenerator.id,
    style: formData.style,
    // ... other params
  }),
})
```

### Step 3: Create API Handler

Create an API route to handle requests to your generator:

```typescript
// app/api/generate-video/route.ts

import { getGeneratorById } from '@/lib/video-generator-config'

export async function POST(request: NextRequest) {
  const { prompt, duration, generatorId, style } = await request.json()
  const generator = getGeneratorById(generatorId)

  if (!generator?.enabled) {
    return NextResponse.json(
      { error: 'Generator not available' },
      { status: 400 }
    )
  }

  try {
    // Call your generator's API
    const response = await fetch(generator.apiEndpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${generator.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        duration,
        style,
      }),
    })

    const videoUrl = await response.json()
    return NextResponse.json({ videoUrl })
  } catch (error) {
    // Fallback to next generator if available
    return NextResponse.json(
      { error: 'Generation failed' },
      { status: 500 }
    )
  }
}
```

## Supported Generators

### Popular Options:

1. **OpenAI DALL-E Video**
   - Endpoint: `https://api.openai.com/v1/videos`
   - Features: All types, custom styles
   - Cost: ~$0.50/video (adjust credits accordingly)

2. **Synthesia**
   - Endpoint: `https://api.synthesia.io/v1/videos`
   - Features: Talking humans
   - Cost: ~$0.75/video

3. **Runway ML**
   - Endpoint: `https://api.runwayml.com/v1/generate`
   - Features: Image-to-video, video editing
   - Cost: ~$0.60/video

4. **HeyGen**
   - Endpoint: `https://api.heygen.com/v1/video_talks`
   - Features: Talking avatar videos
   - Cost: ~$0.80/video

5. **Eleven Labs Video**
   - Endpoint: `https://api.elevenlabs.io/v1/generate_video`
   - Features: Talking videos with voice
   - Cost: ~$0.90/video

6. **Pika Labs**
   - Endpoint: `https://api.pika.art/v1/generate`
   - Features: All types, high quality
   - Cost: Variable based on length

## Configuration File

The main configuration is in `/lib/video-generator-config.ts`:

```typescript
export interface VideoGenerator {
  id: string                      // Unique identifier
  name: string                    // Display name
  description: string             // What it does
  enabled: boolean                // Is it active?
  priority: number                // Lower = higher priority
  apiKey?: string                 // Authentication
  apiEndpoint?: string            // API URL
  creditCost: number              // Cost per generation
  supportedFeatures: {
    talkingAnimals?: boolean
    humanVideos?: boolean
    imageToVideo?: boolean
    customStyles?: boolean
  }
}
```

## Credit System

Credits are flexible - you can set any cost per generator:

```typescript
{
  id: 'my-generator',
  name: 'My Custom Generator',
  creditCost: 100, // Each video costs 100 credits
  // ...
}
```

The system deducts credits based on the generator's `creditCost` field.

## Fallback System

If the primary generator fails, the system automatically tries the next in priority order:

```typescript
// In api/generate-video/route.ts
for (const generatorId of fallbackGenerators) {
  try {
    // Try this generator
    return await generateWithGenerator(generatorId, params)
  } catch (err) {
    // Try next one
    console.log(`Generator ${generatorId} failed, trying next...`)
  }
}
```

## Environment Variables

Store API keys as environment variables:

```bash
# .env.local
VIDEO_GENERATOR_OPENAI_KEY=sk-...
VIDEO_GENERATOR_SYNTHESIA_KEY=...
VIDEO_GENERATOR_RUNWAY_KEY=...
```

Access in code:

```typescript
const apiKey = process.env[`VIDEO_GENERATOR_${generatorId.toUpperCase()}_KEY`]
```

## Admin Management

The admin panel at `/admin/ai-providers` allows you to:

- Enable/disable generators
- Set priority (failover order)
- Update API keys and endpoints
- Adjust credit costs
- View usage statistics

## Testing

To test a generator integration:

1. Add generator in admin panel
2. Set to enabled
3. Go to `/talking-animals` or `/human-videos`
4. Generate a video and check the console logs
5. Verify credits are deducted correctly

## Support

Each generator has different response formats. Map them to our standard format:

```typescript
interface VideoGenerationResponse {
  videoUrl: string
  duration: number
  thumbnailUrl?: string
  status: 'completed' | 'processing' | 'failed'
  generatorId: string
}
```
