'use client'

import { useEffect, useState } from 'react'
import { onAuthStateChanged, User } from 'firebase/auth'
import { getAuth } from '@/lib/firebase'
import { getUserProfile, type UserProfile } from '@/lib/auth-utils'

interface UseAuthReturn {
  user: User | null
  profile: UserProfile | null
  loading: boolean
}

export function useAuth(): UseAuthReturn {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    try {
      const auth = getAuth()
      
      // If Firebase is not initialized, set loading to false and return
      if (!auth) {
        console.warn('[v0] Firebase Auth not available - check environment variables')
        setLoading(false)
        return
      }

      const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
        setUser(currentUser)

        if (currentUser) {
          // Fetch user profile from Firestore
          const userProfile = await getUserProfile(currentUser.uid)
          setProfile(userProfile)
        } else {
          setProfile(null)
        }

        setLoading(false)
      })

      return () => unsubscribe()
    } catch (error) {
      console.error('[v0] useAuth error:', error)
      setLoading(false)
    }
  }, [])

  return { user, profile, loading }
}
