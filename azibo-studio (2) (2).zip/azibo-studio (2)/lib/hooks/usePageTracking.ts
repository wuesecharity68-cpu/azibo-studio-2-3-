'use client'

import { useEffect } from 'react'
import { useAuth } from './useAuth'

export function usePageTracking(page: string = '/') {
  const { user } = useAuth()

  useEffect(() => {
    const trackVisit = async () => {
      try {
        await fetch('/api/track-visit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: user?.uid || null,
            page,
          }),
        })
      } catch (error) {
        console.error('[v0] Failed to track page visit:', error)
      }
    }

    trackVisit()
  }, [page, user?.uid])
}
