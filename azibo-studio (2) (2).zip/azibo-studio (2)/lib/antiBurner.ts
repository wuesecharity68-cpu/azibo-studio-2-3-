import { db } from './db'
import { doc, getDoc, setDoc } from 'firebase/firestore'

export async function checkIPLimit(ip: string) {
  // Check if this IP already used free credits
  const ref = doc(db, 'freeCredits', ip)
  const existing = await getDoc(ref)

  if (existing.exists() && existing.data()?.used) {
    return { allowed: false, reason: 'Free credits already used from this IP' }
  }
  return { allowed: true, reason: '' }
}

export async function markIPUsed(ip: string, userId: string) {
  const ref = doc(db, 'freeCredits', ip)
  await setDoc(ref, { ip, userId, used: true }, { merge: true })
}

export function getClientIP(req: Request) {
  const xf = req.headers.get('x-forwarded-for')
  return xf? xf.split(',')[0].trim() : 'unknown'
}