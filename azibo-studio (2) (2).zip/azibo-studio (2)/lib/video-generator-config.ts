// Video Generator Configuration
// This file manages all video generator integrations
// You can add any video generator by adding it to the generators array

export interface VideoGenerator {
  id: string
  name: string
  description: string
  enabled: boolean
  priority: number
  apiKey?: string
  apiEndpoint?: string
  creditCost: number // Cost per video generation
  supportedFeatures: {
    talkingAnimals?: boolean
    humanVideos?: boolean
    imageToVideo?: boolean
    customStyles?: boolean
  }
}

export interface GeneratorConfig {
  generators: VideoGenerator[]
  defaultGenerator: string
  fallbackGenerators: string[]
}

// Default configuration - customize with your generators
export const defaultGeneratorConfig: GeneratorConfig = {
  generators: [
    {
      id: 'openai-demo',
      name: 'OpenAI DALL-E (Demo)',
      description: 'OpenAI video generation',
      enabled: false,
      priority: 1,
      creditCost: 50,
      supportedFeatures: {
        talkingAnimals: true,
        humanVideos: true,
        imageToVideo: true,
        customStyles: true,
      },
    },
    {
      id: 'synthesia-demo',
      name: 'Synthesia (Demo)',
      description: 'Synthesia video generation for talking humans',
      enabled: false,
      priority: 2,
      creditCost: 75,
      supportedFeatures: {
        humanVideos: true,
        customStyles: true,
      },
    },
    {
      id: 'runway-demo',
      name: 'Runway ML (Demo)',
      description: 'Runway ML for video editing and generation',
      enabled: false,
      priority: 3,
      creditCost: 60,
      supportedFeatures: {
        imageToVideo: true,
        customStyles: true,
      },
    },
  ],
  defaultGenerator: 'openai-demo',
  fallbackGenerators: ['synthesia-demo', 'runway-demo'],
}

// Helper function to get active generators sorted by priority
export function getActiveGenerators(config?: GeneratorConfig): VideoGenerator[] {
  const cfg = config || defaultGeneratorConfig
  return cfg.generators
    .filter((g) => g.enabled)
    .sort((a, b) => a.priority - b.priority)
}

// Helper function to get a generator by ID
export function getGeneratorById(
  id: string,
  config?: GeneratorConfig
): VideoGenerator | undefined {
  const cfg = config || defaultGeneratorConfig
  return cfg.generators.find((g) => g.id === id)
}

// Helper function to get generators that support a specific feature
export function getGeneratorsByFeature(
  feature: keyof VideoGenerator['supportedFeatures'],
  config?: GeneratorConfig
): VideoGenerator[] {
  const cfg = config || defaultGeneratorConfig
  return cfg.generators.filter((g) => g.enabled && g.supportedFeatures[feature])
}

// Helper function to add a new generator (for admin panel)
export function addVideoGenerator(generator: VideoGenerator): VideoGenerator {
  return {
    ...generator,
    id: generator.id || `generator_${Date.now()}`,
  }
}

// Helper function to update generator configuration
export function updateGeneratorConfig(
  generatorId: string,
  updates: Partial<VideoGenerator>,
  config?: GeneratorConfig
): GeneratorConfig {
  const cfg = config || { ...defaultGeneratorConfig }
  const index = cfg.generators.findIndex((g) => g.id === generatorId)

  if (index !== -1) {
    cfg.generators[index] = {
      ...cfg.generators[index],
      ...updates,
    }
  }

  return cfg
}
