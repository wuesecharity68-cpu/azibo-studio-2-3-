// Storage utilities
// Firebase Storage is not used by AZIBO STUDIO.
// Video storage is handled by the external storage provider.

export const formatBytes = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes'

  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return (
    Math.round((bytes / Math.pow(k, i)) * 100) / 100 +
    ' ' +
    sizes[i]
  )
}

// Kept for compatibility with existing components.
// Returns null because Firebase Storage is no longer used.
export const getVideoFileSize = async (
  _storagePath: string
): Promise<number | null> => {
  return null
}

// Returns an empty string when file size is unavailable.
export const getFormattedFileSize = async (
  _storagePath: string
): Promise<string> => {
  return ''
}