type Job = {
  id: string
  userId: string
  prompt: string
  type: 'image' | 'video'
  status: 'pending' | 'processing' | 'done' | 'failed'
}

const queue: Job[] = []
const MAX_CONCURRENT = 3 // only run 3 jobs at a time
let running = 0

export function addToQueue(job: Omit<Job, 'status'>) {
  const newJob: Job = { ...job, status: 'pending' }
  queue.push(newJob)
  processQueue()
  return newJob.id
}

export function getJobStatus(id: string) {
  return queue.find(j => j.id === id)
}

async function processQueue() {
  if (running >= MAX_CONCURRENT || queue.length === 0) return
  
  const job = queue.find(j => j.status === 'pending')
  if (!job) return
  
  job.status = 'processing'
  running++
  
  try {
    // THIS is where we will call your Runway/Pika API
    console.log('Processing job:', job.id)
    await new Promise(resolve => setTimeout(resolve, 5000)) // fake 5s generation
    job.status = 'done'
  } catch {
    job.status = 'failed'
  }
  
  running--
  processQueue()
}