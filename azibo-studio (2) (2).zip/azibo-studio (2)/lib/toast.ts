// Simple toast notifications utility
type ToastType = 'success' | 'error' | 'info' | 'warning'

interface Toast {
  id: string
  message: string
  type: ToastType
  duration?: number
}

let toastListeners: Array<(toast: Toast) => void> = []

export const showToast = (message: string, type: ToastType = 'info', duration: number = 3000) => {
  const id = Math.random().toString(36).substring(2, 11)
  const toast: Toast = {
    id,
    message,
    type,
    duration,
  }

  toastListeners.forEach((listener) => listener(toast))

  if (duration > 0) {
    setTimeout(() => {
      removeToast(id)
    }, duration)
  }

  return id
}

export const removeToast = (id: string) => {
  toastListeners.forEach((listener) => listener({ id, message: '', type: 'info' }))
}

export const subscribeToToasts = (listener: (toast: Toast) => void) => {
  toastListeners.push(listener)
  return () => {
    toastListeners = toastListeners.filter((l) => l !== listener)
  }
}

export type { Toast, ToastType }
