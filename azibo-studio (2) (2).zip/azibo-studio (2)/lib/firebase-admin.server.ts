import { cert, getApps, initializeApp, type App } from 'firebase-admin/app'
import { getAuth, type Auth } from 'firebase-admin/auth'
import { getFirestore, type Firestore } from 'firebase-admin/firestore'
import { getServerEnv } from './env'

let adminApp: App | null = null

const initializeAdmin = (): App => {
  if (adminApp) {
    return adminApp
  }

  const existingApps = getApps()

  if (existingApps.length > 0) {
    adminApp = existingApps[0]
    return adminApp
  }

  const env = getServerEnv()

  if (
    !env.firebaseAdmin.projectId ||
    !env.firebaseAdmin.clientEmail ||
    !env.firebaseAdmin.privateKey
  ) {
    throw new Error(
      'Missing Firebase Admin credentials. Check FIREBASE_ADMIN_PROJECT_ID, FIREBASE_ADMIN_CLIENT_EMAIL, and FIREBASE_ADMIN_PRIVATE_KEY.'
    )
  }

  adminApp = initializeApp({
    credential: cert({
      projectId: env.firebaseAdmin.projectId,
      clientEmail: env.firebaseAdmin.clientEmail,
      privateKey: env.firebaseAdmin.privateKey.replace(/\\n/g, '\n'),
    }),
  })

  return adminApp
}

export const getAdminDb = (): Firestore => {
  const app = initializeAdmin()
  return getFirestore(app)
}

export const getAdminAuth = (): Auth => {
  const app = initializeAdmin()
  return getAuth(app)
}