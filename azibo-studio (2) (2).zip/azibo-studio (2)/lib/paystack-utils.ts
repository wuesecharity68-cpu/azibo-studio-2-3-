import crypto from 'crypto'

export const verifyPaystackSignature = (body: string, signature: string, secret: string): boolean => {
  const hash = crypto.createHmac('sha512', secret).update(body).digest('hex')
  return hash === signature
}

export interface PaystackWebhookData {
  event: string
  data: {
    id: number
    reference: string
    amount: number
    paid_at: string
    paidAt: string
    customer: {
      id: number
      customer_code: string
      first_name: string
      last_name: string
      email: string
      phone: string
    }
    metadata: {
      plan_id?: string
      user_id?: string
      plan_name?: string
      credits?: number
      [key: string]: any
    }
    status: string
    authorization: {
      authorization_code: string
      bin: string
      last4: string
      exp_month: string
      exp_year: string
      channel: string
      card_type: string
      bank: string
      country_code: string
      brand: string
      reusable: boolean
    }
  }
}

export const processPaystackPayment = async (
  webhookData: PaystackWebhookData,
  updateCredits: (userId: string, credits: number, planId: string) => Promise<void>
) => {
  const { data } = webhookData

  if (data.status !== 'success') {
    throw new Error(`Payment not successful: ${data.status}`)
  }

  const userId = data.metadata.user_id
  const planId = data.metadata.plan_id
  const credits = data.metadata.credits

  if (!userId || !planId || !credits) {
    throw new Error('Missing required metadata: user_id, plan_id, or credits')
  }

  // Update user credits in Firestore
  await updateCredits(userId, credits, planId)

  // Log transaction
  return {
    reference: data.reference,
    amount: data.amount,
    customer_email: data.customer.email,
    timestamp: data.paidAt || data.paid_at,
  }
}
