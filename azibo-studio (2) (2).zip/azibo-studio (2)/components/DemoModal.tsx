'use client'

import { X } from 'lucide-react'

interface DemoModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export default function DemoModal({ open, onOpenChange }: DemoModalProps) {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80">
      <div className="relative w-full max-w-4xl mx-4">
        {/* Close button */}
        <button
          onClick={() => onOpenChange(false)}
          className="absolute -top-10 right-0 text-muted-foreground hover:text-foreground transition-colors z-10"
        >
          <X className="h-6 w-6" />
        </button>

        {/* Video container */}
        <div className="relative w-full bg-black rounded-lg overflow-hidden" style={{ paddingBottom: '56.25%' }}>
          <iframe
            src="https://www.youtube.com/embed/dQw4w9WgXcQ"
            title="AZIBO STUDIO Demo"
            className="absolute inset-0 w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div>
    </div>
  )
}
