'use client'

import { useEffect, useState } from 'react'
import { AlertTriangle } from 'lucide-react'

export function MaintenanceModeAlert() {
  const [maintenanceMode, setMaintenanceMode] = useState(false)
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)

    // Check if maintenance mode is enabled from admin settings
    const checkMaintenanceMode = async () => {
      try {
        // TODO: Fetch from Firestore admin_config collection
        // For now, check localStorage for testing
        const isEnabled = localStorage.getItem('maintenanceMode') === 'true'
        setMaintenanceMode(isEnabled)
      } catch (error) {
        console.error('[v0] Error checking maintenance mode:', error)
      }
    }

    checkMaintenanceMode()
  }, [])

  if (!isClient || !maintenanceMode) return null

  return (
    <div className="fixed top-20 left-0 right-0 bg-destructive/10 border-b border-destructive/50 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-4">
        <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0" />
        <div>
          <h3 className="font-semibold text-destructive">Website Under Maintenance</h3>
          <p className="text-sm text-destructive/80">Downloads are temporarily paused. Please check back soon.</p>
        </div>
      </div>
    </div>
  )
}
