'use client'

import { Video, Users, Music, Sparkles } from 'lucide-react'

export default function WhyAzibo() {
  const features = [
    {
      icon: Video,
      title: 'Text to Video',
      description: 'Convert your ideas into professional videos with a single prompt',
    },
    {
      icon: Users,
      title: 'Talking Animals & Humans',
      description: 'Create characters with perfect lip sync and natural expressions',
    },
    {
      icon: Music,
      title: 'Background Music & SFX',
      description: 'Add music, laughter tracks, and sound effects automatically',
    },
    {
      icon: Sparkles,
      title: 'Multiple Styles',
      description: 'Choose from anime, cartoon, 3D, or realistic rendering styles',
    },
  ]

  return (
    <section className="py-20 px-4 bg-card/50">
      <div className="max-w-5xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
            Why Pay For 5 Different AI Tools?
          </h2>
          <p className="text-lg text-muted-foreground text-balance max-w-2xl mx-auto">
            Text to Video. Image to Video. Talking Animals. Human Stories. All in ONE tool. Stop wasting money on multiple subscriptions.
          </p>
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature) => {
            const Icon = feature.icon
            return (
              <div key={feature.title} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/20">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
