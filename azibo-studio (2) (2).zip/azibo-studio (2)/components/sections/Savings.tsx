'use client'

export default function Savings() {
  return (
    <section className="py-20 px-4 bg-gradient-to-r from-primary/10 to-secondary/10">
      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-block mb-4 px-4 py-2 bg-primary/20 rounded-full">
          <span className="text-primary font-semibold text-sm">Save Money</span>
        </div>

        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
          Save 70% of Your Money
        </h2>

        <p className="text-xl text-muted-foreground mb-12 text-balance max-w-2xl mx-auto">
          Generate unlimited videos using one tool instead of paying for 3-4 different AI platforms. More features, less cost. No hidden charges.
        </p>

        {/* Comparison cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Multiple tools */}
          <div className="p-6 bg-card/80 border border-border rounded-lg text-left">
            <h3 className="text-lg font-semibold text-foreground mb-4">Typical AI Tools Stack</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-muted-foreground">
                <span className="text-red-500">✕</span>
                Text-to-video tool: ₦200k+/month
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <span className="text-red-500">✕</span>
                Image-to-video tool: ₦150k/month
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <span className="text-red-500">✕</span>
                Voice generation: ₦100k/month
              </li>
              <li className="flex items-center gap-3 text-muted-foreground">
                <span className="text-red-500">✕</span>
                Music library: ₦50k/month
              </li>
              <li className="flex items-center gap-2 text-lg font-bold text-foreground mt-4 pt-4 border-t border-border">
                <span className="text-red-500">Total:</span>
                ₦500k+/month
              </li>
            </ul>
          </div>

          {/* AZIBO STUDIO */}
          <div className="p-6 bg-card border-2 border-primary rounded-lg text-left">
            <h3 className="text-lg font-semibold text-foreground mb-4">AZIBO STUDIO</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-foreground">
                <span className="text-primary">✓</span>
                Text & Image to Video
              </li>
              <li className="flex items-center gap-3 text-foreground">
                <span className="text-primary">✓</span>
                Talking Animals & Humans
              </li>
              <li className="flex items-center gap-3 text-foreground">
                <span className="text-primary">✓</span>
                Voice & Music Included
              </li>
              <li className="flex items-center gap-3 text-foreground">
                <span className="text-primary">✓</span>
                Multiple Styles
              </li>
              <li className="flex items-center gap-2 text-lg font-bold text-primary mt-4 pt-4 border-t border-border">
                <span className="text-primary">✓</span>
                ₦158k-950k/month
              </li>
            </ul>
          </div>
        </div>

        <p className="text-sm text-muted-foreground">
          That&apos;s a savings of <span className="font-bold text-primary">70% or more!</span>
        </p>
      </div>
    </section>
  )
}
