'use client'

import { ProtectedRoute } from '@/components/ProtectedRoute'
import { useToast } from '@/lib/hooks/useToast'
import Link from 'next/link'
import { ArrowLeft, Save } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'

const DEFAULT_PACKAGES = [
  {
    name: 'Starter',
    monthlyPrice: 47500,
    yearlyPrice: 95000,
    monthlyCredits: 100,
    yearlyCredits: 1200,
  },
  {
    name: 'Creator',
    monthlyPrice: 158000,
    yearlyPrice: 475000,
    monthlyCredits: 500,
    yearlyCredits: 6000,
  },
  {
    name: 'Pro',
    monthlyPrice: 950000,
    yearlyPrice: 1580000,
    monthlyCredits: 2000,
    yearlyCredits: 24000,
  },
]

function CreditPackagesContent() {
  const { success, error } = useToast()
  const [packages, setPackages] = useState(DEFAULT_PACKAGES)
  const [saving, setSaving] = useState(false)

  const handleUpdatePackage = (index: number, field: string, value: any) => {
    const newPackages = [...packages]
    newPackages[index] = { ...newPackages[index], [field]: value }
    setPackages(newPackages)
  }

  const handleSave = async () => {
    try {
      setSaving(true)
      // TODO: Save to Firestore credit_packages collection
      success('Credit packages saved successfully')
    } catch (err) {
      console.error('[v0] Error saving packages:', err)
      error('Failed to save credit packages')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <Link href="/admin" className="flex items-center gap-2 text-primary hover:text-primary/80 mb-4">
            <ArrowLeft className="h-5 w-5" />
            Back to Admin
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Credit Packages</h1>
          <p className="text-sm text-muted-foreground">Configure pricing and credit allocations</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-6">
          {packages.map((pkg, index) => (
            <div key={index} className="bg-card border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-6">{pkg.name} Plan</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div>
                  <label className="block text-sm text-muted-foreground mb-2">Monthly Price (₦)</label>
                  <input
                    type="number"
                    value={pkg.monthlyPrice}
                    onChange={(e) => handleUpdatePackage(index, 'monthlyPrice', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm text-muted-foreground mb-2">Yearly Price (₦)</label>
                  <input
                    type="number"
                    value={pkg.yearlyPrice}
                    onChange={(e) => handleUpdatePackage(index, 'yearlyPrice', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm text-muted-foreground mb-2">Monthly Credits</label>
                  <input
                    type="number"
                    value={pkg.monthlyCredits}
                    onChange={(e) => handleUpdatePackage(index, 'monthlyCredits', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm text-muted-foreground mb-2">Yearly Credits</label>
                  <input
                    type="number"
                    value={pkg.yearlyCredits}
                    onChange={(e) => handleUpdatePackage(index, 'yearlyCredits', parseInt(e.target.value))}
                    className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>
            </div>
          ))}

          <Button onClick={handleSave} disabled={saving} className="w-full md:w-auto">
            <Save size={18} className="mr-2" />
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </main>
    </div>
  )
}

export default function AdminCreditPackagesPage() {
  return (
    <ProtectedRoute requiredRole="owner">
      <CreditPackagesContent />
    </ProtectedRoute>
  )
}
