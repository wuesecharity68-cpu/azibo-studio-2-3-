'use client'

import { ProtectedRoute } from '@/components/ProtectedRoute'
import { useAuth } from '@/lib/hooks/useAuth'
import { useToast } from '@/lib/hooks/useToast'
import Link from 'next/link'
import { Settings, BarChart3, Users, Package } from 'lucide-react'

function AdminContent() {
  const { profile } = useAuth()
  const { error } = useToast()

  if (profile?.role !== 'owner') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="max-w-md w-full text-center">
          <h1 className="text-3xl font-bold text-foreground mb-2">Access Denied</h1>
          <p className="text-muted-foreground mb-6">Only the owner can access the admin dashboard.</p>
          <Link href="/dashboard" className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90">
            Go to Dashboard
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-primary">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground">Manage your AZIBO STUDIO platform</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Dashboard cards */}
          <Link
            href="/admin/analytics"
            className="bg-card border border-border rounded-lg p-6 hover:border-primary transition-colors group"
          >
            <div className="h-10 w-10 bg-primary/20 rounded-lg flex items-center justify-center group-hover:bg-primary/30 transition-colors mb-4">
              <BarChart3 className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-1">Analytics</h3>
            <p className="text-sm text-muted-foreground">View usage and revenue analytics</p>
          </Link>

          <Link
            href="/admin/users"
            className="bg-card border border-border rounded-lg p-6 hover:border-primary transition-colors group"
          >
            <div className="h-10 w-10 bg-secondary/20 rounded-lg flex items-center justify-center group-hover:bg-secondary/30 transition-colors mb-4">
              <Users className="h-6 w-6 text-secondary" />
            </div>
            <h3 className="font-semibold text-foreground mb-1">Users</h3>
            <p className="text-sm text-muted-foreground">Manage user accounts and subscriptions</p>
          </Link>

          <Link
            href="/admin/credit-packages"
            className="bg-card border border-border rounded-lg p-6 hover:border-primary transition-colors group"
          >
            <div className="h-10 w-10 bg-primary/20 rounded-lg flex items-center justify-center group-hover:bg-primary/30 transition-colors mb-4">
              <Package className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-1">Credit Packages</h3>
            <p className="text-sm text-muted-foreground">Configure pricing and credit plans</p>
          </Link>

          <Link
            href="/admin/settings"
            className="bg-card border border-border rounded-lg p-6 hover:border-primary transition-colors group"
          >
            <div className="h-10 w-10 bg-primary/20 rounded-lg flex items-center justify-center group-hover:bg-primary/30 transition-colors mb-4">
              <Settings className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-1">Settings</h3>
            <p className="text-sm text-muted-foreground">Configure site settings and branding</p>
          </Link>
        </div>

        {/* Quick stats */}
        <div className="bg-card border border-border rounded-lg p-8">
          <h2 className="text-2xl font-bold text-foreground mb-6">Platform Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Total Users</p>
              <p className="text-4xl font-bold text-primary">0</p>
              <p className="text-xs text-muted-foreground mt-2">No data yet</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Total Revenue</p>
              <p className="text-4xl font-bold text-primary">₦0</p>
              <p className="text-xs text-muted-foreground mt-2">This month</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Videos Generated</p>
              <p className="text-4xl font-bold text-primary">0</p>
              <p className="text-xs text-muted-foreground mt-2">All time</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default function AdminPage() {
  return (
    <ProtectedRoute requiredRole="owner">
      <AdminContent />
    </ProtectedRoute>
  )
}
