'use client'

import { useEffect, useState } from 'react'
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  doc,
  deleteDoc,
  setDoc,
} from 'firebase/firestore'
import { getDb } from '@/lib/firebase'
import { useToast } from '@/lib/hooks/useToast'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { Button } from '@/components/ui/button'
import { Trash2, Plus, Star } from 'lucide-react'

interface Testimonial {
  id: string
  name: string
  role: string
  photo: string
  quote: string
  rating: number
  createdAt: number
}

export default function AdminTestimonialsPage() {
  return (
    <ProtectedRoute requiredRole="owner">
      <TestimonialsContent />
    </ProtectedRoute>
  )
}

function TestimonialsContent() {
  const toast = useToast()
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    name: '',
    role: '',
    photo: '',
    quote: '',
    rating: 5,
  })

  useEffect(() => {
    try {
      const db = getDb()

      if (!db) {
        console.error('[AZIBO] Firestore database is not available')
        setLoading(false)
        return
      }

      const q = query(
        collection(db, 'testimonials'),
        orderBy('createdAt', 'desc')
      )

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const data: Testimonial[] = []

          snapshot.forEach((snapshotDoc) => {
            data.push({
              id: snapshotDoc.id,
              ...snapshotDoc.data(),
            } as Testimonial)
          })

          setTestimonials(data)
          setLoading(false)
        },
        (snapshotError) => {
          console.error(
            '[AZIBO] Error listening to testimonials:',
            snapshotError
          )
          setLoading(false)
        }
      )

      return () => unsubscribe()
    } catch (error) {
      console.error('[AZIBO] Error fetching testimonials:', error)
      setLoading(false)
    }
  }, [])

  const handleAddTestimonial = async () => {
    if (!formData.name || !formData.quote) {
      toast.error('Name and quote are required')
      return
    }

    try {
      const db = getDb()

      if (!db) {
        toast.error('Database is not available')
        return
      }

      const newId = editingId || Date.now().toString()

      const testimonialData = editingId
        ? {
            ...formData,
          }
        : {
            ...formData,
            createdAt: Date.now(),
          }

      await setDoc(
        doc(db, 'testimonials', newId),
        testimonialData,
        { merge: true }
      )

      toast.success(
        editingId
          ? 'Testimonial updated'
          : 'Testimonial added'
      )

      setFormData({
        name: '',
        role: '',
        photo: '',
        quote: '',
        rating: 5,
      })

      setEditingId(null)
      setShowForm(false)
    } catch (error) {
      console.error('[AZIBO] Error saving testimonial:', error)
      toast.error('Failed to save testimonial')
    }
  }

  const handleDeleteTestimonial = async (id: string) => {
    if (
      !confirm(
        'Are you sure you want to delete this testimonial?'
      )
    ) {
      return
    }

    try {
      const db = getDb()

      if (!db) {
        toast.error('Database is not available')
        return
      }

      await deleteDoc(doc(db, 'testimonials', id))

      toast.success('Testimonial deleted')
    } catch (error) {
      console.error(
        '[AZIBO] Error deleting testimonial:',
        error
      )
      toast.error('Failed to delete testimonial')
    }
  }

  const handleEditTestimonial = (
    testimonial: Testimonial
  ) => {
    setFormData({
      name: testimonial.name,
      role: testimonial.role,
      photo: testimonial.photo,
      quote: testimonial.quote,
      rating: testimonial.rating,
    })

    setEditingId(testimonial.id)
    setShowForm(true)
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-primary">
            Manage Testimonials
          </h1>

          <p className="text-sm text-muted-foreground">
            Add, edit, or remove customer testimonials
          </p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {showForm && (
          <div className="bg-card border border-border rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-6">
              {editingId
                ? 'Edit Testimonial'
                : 'Add New Testimonial'}
            </h2>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="Name"
                value={formData.name}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    name: e.target.value,
                  })
                }
                className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />

              <input
                type="text"
                placeholder="Role (e.g. Content Creator, Business Owner)"
                value={formData.role}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    role: e.target.value,
                  })
                }
                className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />

              <input
                type="url"
                placeholder="Photo URL"
                value={formData.photo}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    photo: e.target.value,
                  })
                }
                className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />

              <textarea
                placeholder="Testimonial quote"
                value={formData.quote}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    quote: e.target.value,
                  })
                }
                className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                rows={4}
              />

              <div className="flex items-center gap-4">
                <label className="text-sm text-muted-foreground">
                  Rating:
                </label>

                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() =>
                        setFormData({
                          ...formData,
                          rating: n,
                        })
                      }
                      className={`p-1 transition-colors ${
                        formData.rating >= n
                          ? 'text-primary'
                          : 'text-muted-foreground hover:text-primary'
                      }`}
                    >
                      <Star
                        size={20}
                        fill={
                          formData.rating >= n
                            ? 'currentColor'
                            : 'none'
                        }
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleAddTestimonial}
                  className="flex-1"
                >
                  {editingId ? 'Update' : 'Add'}
                </Button>

                <Button
                  onClick={() => {
                    setShowForm(false)
                    setEditingId(null)
                    setFormData({
                      name: '',
                      role: '',
                      photo: '',
                      quote: '',
                      rating: 5,
                    })
                  }}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {!showForm && (
          <Button
            onClick={() => setShowForm(true)}
            className="mb-8"
          >
            <Plus size={18} className="mr-2" />
            Add Testimonial
          </Button>
        )}

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              Loading testimonials...
            </p>
          </div>
        ) : testimonials.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              No testimonials yet. Add one to get started.
            </p>
          </div>
        ) : (
          <div className="grid gap-6">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.id}
                className="bg-card border border-border rounded-lg p-6"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="flex gap-4 flex-1">
                    {testimonial.photo && (
                      <img
                        src={testimonial.photo}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    )}

                    <div>
                      <h3 className="font-semibold text-foreground">
                        {testimonial.name}
                      </h3>

                      <p className="text-sm text-muted-foreground">
                        {testimonial.role}
                      </p>

                      <div className="flex gap-1 mt-2">
                        {[
                          ...Array(testimonial.rating),
                        ].map((_, i) => (
                          <Star
                            key={i}
                            size={16}
                            className="text-primary"
                            fill="currentColor"
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() =>
                        handleEditTestimonial(testimonial)
                      }
                      variant="outline"
                      size="sm"
                    >
                      Edit
                    </Button>

                    <Button
                      onClick={() =>
                        handleDeleteTestimonial(
                          testimonial.id
                        )
                      }
                      variant="destructive"
                      size="sm"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>

                <p className="text-foreground italic">
                  {testimonial.quote}
                </p>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}