'use client'

import { ProtectedRoute } from '@/components/ProtectedRoute'
import Link from 'next/link'
import { ArrowLeft, TrendingUp, DollarSign, Film, Users } from 'lucide-react'

export default function AdminAnalyticsPage() {
  return (
    <ProtectedRoute requiredRole="owner">
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <Link href="/admin" className="flex items-center gap-2 text-primary hover:text-primary/80 mb-4">
              <ArrowLeft className="h-5 w-5" />
              Back to Admin
            </Link>
            <h1 className="text-2xl font-bold text-foreground">Analytics & Reports</h1>
            <p className="text-sm text-muted-foreground">View platform performance and revenue metrics</p>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* Key Metrics */}
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Revenue</p>
                  <p className="text-3xl font-bold text-primary">₦0</p>
                </div>
                <DollarSign className="h-8 w-8 text-primary/30" />
              </div>
            </div>

            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Active Users</p>
                  <p className="text-3xl font-bold text-secondary">0</p>
                </div>
                <Users className="h-8 w-8 text-secondary/30" />
              </div>
            </div>

            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Videos Generated</p>
                  <p className="text-3xl font-bold text-primary">0</p>
                </div>
                <Film className="h-8 w-8 text-primary/30" />
              </div>
            </div>

            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Profit Margin</p>
                  <p className="text-3xl font-bold text-secondary">0%</p>
                </div>
                <TrendingUp className="h-8 w-8 text-secondary/30" />
              </div>
            </div>
          </div>

          {/* Data Tables */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Revenue by Plan */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Revenue by Plan</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Starter</span>
                  <span className="font-semibold text-foreground">₦0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Creator</span>
                  <span className="font-semibold text-foreground">₦0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Pro</span>
                  <span className="font-semibold text-foreground">₦0</span>
                </div>
              </div>
            </div>

            {/* Cost Analytics */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Cost per Video</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Avg Cost</span>
                  <span className="font-semibold text-foreground">₦0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Total Cost</span>
                  <span className="font-semibold text-foreground">₦0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Cost per User</span>
                  <span className="font-semibold text-foreground">₦0</span>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
