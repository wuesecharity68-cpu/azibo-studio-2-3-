'use client'

import { useState } from 'react'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { useToast } from '@/lib/hooks/useToast'
import Link from 'next/link'
import { ArrowLeft, Save } from 'lucide-react'
import { Button } from '@/components/ui/button'

function AdminSettingsContent() {
  const toast = useToast()
  const [saving, setSaving] = useState(false)
  const [settings, setSettings] = useState({
    siteName: 'AZIBO STUDIO',
    siteDescription: 'Create Viral AI Videos In Seconds',
    maintenanceMode: false,
    watermarkEnabled: true,
    defaultCredits: 50,
    supportEmail: 'support@azibo.studio',
  })

  const handleSave = async () => {
    try {
      setSaving(true)
      // TODO: Save to Firestore admin_config collection
      toast.success('Settings saved successfully')
    } catch (err) {
      console.error('[v0] Error saving settings:', err)
      toast.error('Failed to save settings')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <Link href="/admin" className="flex items-center gap-2 text-primary hover:text-primary/80 mb-4">
            <ArrowLeft className="h-5 w-5" />
            Back to Admin
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Admin Settings</h1>
          <p className="text-sm text-muted-foreground">Configure platform settings and branding</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Site Branding */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-lg font-semibold text-foreground mb-6">Site Branding</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-muted-foreground mb-2">Site Name</label>
                <input
                  type="text"
                  value={settings.siteName}
                  onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm text-muted-foreground mb-2">Site Description</label>
                <input
                  type="text"
                  value={settings.siteDescription}
                  onChange={(e) => setSettings({ ...settings, siteDescription: e.target.value })}
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm text-muted-foreground mb-2">Support Email</label>
                <input
                  type="email"
                  value={settings.supportEmail}
                  onChange={(e) => setSettings({ ...settings, supportEmail: e.target.value })}
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
          </div>

          {/* Platform Settings */}
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-lg font-semibold text-foreground mb-6">Platform Settings</h2>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Maintenance Mode</label>
                  <p className="text-xs text-muted-foreground mt-1">
                    When enabled, only admins can access the platform
                  </p>
                </div>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.maintenanceMode}
                    onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
                    className="w-4 h-4 rounded border border-border"
                  />
                </label>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-medium text-foreground">Watermark Enabled</label>
                  <p className="text-xs text-muted-foreground mt-1">
                    Add AZIBO STUDIO watermark to user videos
                  </p>
                </div>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.watermarkEnabled}
                    onChange={(e) => setSettings({ ...settings, watermarkEnabled: e.target.checked })}
                    className="w-4 h-4 rounded border border-border"
                  />
                </label>
              </div>

              <div>
                <label className="block text-sm text-muted-foreground mb-2">Default Free Credits</label>
                <input
                  type="number"
                  value={settings.defaultCredits}
                  onChange={(e) => setSettings({ ...settings, defaultCredits: parseInt(e.target.value) })}
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full md:w-auto">
            <Save size={18} className="mr-2" />
            {saving ? 'Saving...' : 'Save Settings'}
          </Button>
        </div>
      </main>
    </div>
  )
}

export default function AdminSettingsPage() {
  return (
    <ProtectedRoute requiredRole="owner">
      <AdminSettingsContent />
    </ProtectedRoute>
  )
}
