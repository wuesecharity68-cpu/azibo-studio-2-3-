'use client'

import { useEffect, useState } from 'react'
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore'
import { getDb } from '@/lib/firebase'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { useToast } from '@/lib/hooks/useToast'
import Link from 'next/link'
import { ArrowLeft, Save, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface AIProvider {
  id: string
  name: string
  apiKey: string
  enabled: boolean
  priority: number
  status: 'active' | 'inactive' | 'error'
  creditsPerVideo: number
}

function AdminAIProvidersContent() {
  const { success, error } = useToast()
  const [providers, setProviders] = useState<AIProvider[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    name: '',
    apiKey: '',
    enabled: true,
    priority: 1,
    creditsPerVideo: 50,
  })

  useEffect(() => {
    try {
      const db = getDb()

      if (!db) {
        console.error('[AZIBO] Firestore database is not available')
        setLoading(false)
        return
      }

      const q = query(
        collection(db, 'ai_providers'),
        orderBy('priority', 'asc')
      )

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const data: AIProvider[] = []

          snapshot.forEach((doc) => {
            data.push({
              id: doc.id,
              ...doc.data(),
            } as AIProvider)
          })

          setProviders(data)
          setLoading(false)
        },
        (snapshotError) => {
          console.error(
            '[AZIBO] Error listening to AI providers:',
            snapshotError
          )
          setLoading(false)
        }
      )

      return () => unsubscribe()
    } catch (err) {
      console.error('[AZIBO] Error fetching AI providers:', err)
      setLoading(false)
    }
  }, [])

  const handleSave = async () => {
    if (!formData.name || !formData.apiKey) {
      error('Provider name and API key are required')
      return
    }

    try {
      setSaving(true)

      // TODO: Save to Firestore ai_providers collection
      success(editingId ? 'Provider updated' : 'Provider added')

      setFormData({
        name: '',
        apiKey: '',
        enabled: true,
        priority: 1,
        creditsPerVideo: 50,
      })

      setEditingId(null)
      setShowForm(false)
    } catch (err) {
      console.error('[AZIBO] Error saving provider:', err)
      error('Failed to save provider')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this provider?')) return

    try {
      // TODO: Delete from Firestore
      success('Provider deleted')
    } catch (err) {
      console.error('[AZIBO] Error deleting provider:', err)
      error('Failed to delete provider')
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <Link
            href="/admin"
            className="flex items-center gap-2 text-primary hover:text-primary/80 mb-4"
          >
            <ArrowLeft className="h-5 w-5" />
            Back to Admin
          </Link>

          <h1 className="text-2xl font-bold text-foreground">
            AI Providers
          </h1>

          <p className="text-sm text-muted-foreground">
            Manage video generation providers and failover settings
          </p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {!showForm ? (
          <>
            <Button onClick={() => setShowForm(true)} className="mb-8">
              <Plus className="h-4 w-4 mr-2" />
              Add Provider
            </Button>

            {loading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">
                  Loading providers...
                </p>
              </div>
            ) : providers.length === 0 ? (
              <div className="bg-card border border-border rounded-lg p-8 text-center">
                <p className="text-muted-foreground mb-4">
                  No AI providers configured yet
                </p>

                <Button onClick={() => setShowForm(true)}>
                  Add First Provider
                </Button>
              </div>
            ) : (
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="border-b border-border bg-background">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Priority
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Credits/Video
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {providers.map((provider) => (
                      <tr
                        key={provider.id}
                        className="border-b border-border hover:bg-background/50"
                      >
                        <td className="px-6 py-3 text-sm">
                          {provider.priority}
                        </td>

                        <td className="px-6 py-3 text-sm font-medium">
                          {provider.name}
                        </td>

                        <td className="px-6 py-3 text-sm">
                          <span
                            className={`px-2 py-1 rounded text-xs font-medium ${
                              provider.enabled
                                ? 'bg-primary/20 text-primary'
                                : 'bg-muted text-muted-foreground'
                            }`}
                          >
                            {provider.enabled
                              ? 'Enabled'
                              : 'Disabled'}
                          </span>
                        </td>

                        <td className="px-6 py-3 text-sm">
                          {provider.creditsPerVideo}
                        </td>

                        <td className="px-6 py-3 text-sm">
                          <button
                            onClick={() =>
                              handleDelete(provider.id)
                            }
                            className="text-destructive hover:text-destructive/80"
                            type="button"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        ) : (
          <div className="bg-card border border-border rounded-lg p-8 max-w-2xl">
            <h2 className="text-xl font-semibold mb-6">
              {editingId
                ? 'Edit Provider'
                : 'Add New Provider'}
            </h2>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm text-muted-foreground mb-2">
                  Provider Name
                </label>

                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      name: e.target.value,
                    })
                  }
                  placeholder="e.g., HeyGen, Synthesia"
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm text-muted-foreground mb-2">
                  API Key
                </label>

                <input
                  type="password"
                  value={formData.apiKey}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      apiKey: e.target.value,
                    })
                  }
                  placeholder="Enter API key"
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-muted-foreground mb-2">
                    Priority
                  </label>

                  <input
                    type="number"
                    value={formData.priority}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        priority: parseInt(
                          e.target.value,
                          10
                        ),
                      })
                    }
                    className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm text-muted-foreground mb-2">
                    Credits per Video
                  </label>

                  <input
                    type="number"
                    value={formData.creditsPerVideo}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        creditsPerVideo: parseInt(
                          e.target.value,
                          10
                        ),
                      })
                    }
                    className="w-full px-4 py-2 bg-background border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.enabled}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      enabled: e.target.checked,
                    })
                  }
                  className="h-4 w-4 rounded border-border"
                />

                <label className="ml-2 text-sm text-foreground">
                  Enable this provider
                </label>
              </div>
            </div>

            <div className="flex gap-4">
              <Button
                onClick={handleSave}
                disabled={saving}
              >
                <Save className="h-4 w-4 mr-2" />
                {saving
                  ? 'Saving...'
                  : 'Save Provider'}
              </Button>

              <Button
                variant="outline"
                onClick={() => {
                  setShowForm(false)
                  setEditingId(null)
                  setFormData({
                    name: '',
                    apiKey: '',
                    enabled: true,
                    priority: 1,
                    creditsPerVideo: 50,
                  })
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

export default function AdminAIProvidersPage() {
  return (
    <ProtectedRoute requiredRole="owner">
      <AdminAIProvidersContent />
    </ProtectedRoute>
  )
}