'use client'

import { useEffect, useState } from 'react'
import { collection, query, orderBy, onSnapshot, limit } from 'firebase/firestore'
import { getDb } from '@/lib/firebase'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import Link from 'next/link'
import { ArrowLeft, Globe } from 'lucide-react'

interface PageVisit {
  id: string
  timestamp: number
  userAgent: string
  userId?: string
}

interface User {
  uid: string
  email: string
  displayName: string
  credits: number
  createdAt: number
  subscriptionPlan: string
}

function AdminUsersContent() {
  const [users, setUsers] = useState<User[]>([])
  const [visits, setVisits] = useState<PageVisit[]>([])
  const [loading, setLoading] = useState(true)

  // Fetch users
  useEffect(() => {
    try {
      const db = getDb()
      const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(100))

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const data: User[] = []
        snapshot.forEach((doc) => {
          data.push({
            uid: doc.id,
            ...doc.data(),
          } as User)
        })
        setUsers(data)
        setLoading(false)
      })

      return () => unsubscribe()
    } catch (error) {
      console.error('[v0] Error fetching users:', error)
      setLoading(false)
    }
  }, [])

  // Fetch page visits
  useEffect(() => {
    try {
      const db = getDb()
      const q = query(collection(db, 'page_visits'), orderBy('timestamp', 'desc'), limit(50))

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const data: PageVisit[] = []
        snapshot.forEach((doc) => {
          data.push({
            id: doc.id,
            ...doc.data(),
          } as PageVisit)
        })
        setVisits(data)
      })

      return () => unsubscribe()
    } catch (error) {
      console.error('[v0] Error fetching visits:', error)
    }
  }, [])

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <Link href="/admin" className="flex items-center gap-2 text-primary hover:text-primary/80 mb-4">
            <ArrowLeft className="h-5 w-5" />
            Back to Admin
          </Link>
          <h1 className="text-2xl font-bold text-foreground">User Management</h1>
          <p className="text-sm text-muted-foreground">Manage users and view visitor analytics</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Users Section */}
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-4">Users ({users.length})</h2>
            {loading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Loading users...</p>
              </div>
            ) : users.length === 0 ? (
              <div className="bg-card border border-border rounded-lg p-6 text-center">
                <p className="text-muted-foreground">No users yet</p>
              </div>
            ) : (
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border bg-background">
                      <tr>
                        <th className="px-4 py-2 text-left font-semibold text-foreground">Email</th>
                        <th className="px-4 py-2 text-left font-semibold text-foreground">Credits</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((user) => (
                        <tr key={user.uid} className="border-b border-border hover:bg-background/50">
                          <td className="px-4 py-3 text-foreground text-xs">{user.email}</td>
                          <td className="px-4 py-3 text-muted-foreground text-xs">{user.credits}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Visits Section */}
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
              <Globe size={20} />
              Recent Visits ({visits.length})
            </h2>
            {visits.length === 0 ? (
              <div className="bg-card border border-border rounded-lg p-6 text-center">
                <p className="text-muted-foreground">No visits tracked yet</p>
              </div>
            ) : (
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border bg-background">
                      <tr>
                        <th className="px-4 py-2 text-left font-semibold text-foreground">Time</th>
                        <th className="px-4 py-2 text-left font-semibold text-foreground">User</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visits.slice(0, 10).map((visit) => (
                        <tr key={visit.id} className="border-b border-border hover:bg-background/50">
                          <td className="px-4 py-3 text-muted-foreground text-xs">
                            {formatDate(visit.timestamp)}
                          </td>
                          <td className="px-4 py-3 text-foreground text-xs">
                            {visit.userId ? 'Authenticated' : 'Anonymous'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

export default function AdminUsersPage() {
  return (
    <ProtectedRoute requiredRole="owner">
      <AdminUsersContent />
    </ProtectedRoute>
  )
}
