'use client'

import { ProtectedRoute } from '@/components/ProtectedRoute'
import { useAuth } from '@/lib/hooks/useAuth'
import { useToast } from '@/lib/hooks/useToast'
import { VideoPlayer } from '@/components/VideoPlayer'
import {
  getActiveGenerators,
  defaultGeneratorConfig,
} from '@/lib/video-generator-config'
import Link from 'next/link'
import { useMemo, useState } from 'react'
import { ArrowLeft, Loader2, Upload } from 'lucide-react'

type GeneratedVideo = {
  id: string
  url: string
}

type FormDataState = {
  prompt: string
  duration: string
  style: string
  genre: string
  voiceGender: string
  includeMusic: boolean
  includeLaughter: boolean
  imageFile: File | null
}

function HumanVideosContent() {
  const { user, profile } = useAuth()
  const { success, error } = useToast()

  const [loading, setLoading] = useState(false)
  const [generatedVideo, setGeneratedVideo] =
    useState<GeneratedVideo | null>(null)

  const availableGenerators = useMemo(
    () => getActiveGenerators(defaultGeneratorConfig),
    []
  )

  const primaryGenerator = availableGenerators[0]
  const creditCost = primaryGenerator?.creditCost || 75

  const [formData, setFormData] = useState<FormDataState>({
    prompt: '',
    duration: '30',
    style: 'realistic',
    genre: 'commercial',
    voiceGender: 'male',
    includeMusic: true,
    includeLaughter: false,
    imageFile: null,
  })

  const [imagePreview, setImagePreview] = useState<string | null>(null)

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value, type } = e.target

    setFormData((prev) => ({
      ...prev,
      [name]:
        type === 'checkbox'
          ? (e.target as HTMLInputElement).checked
          : value,
    }))
  }

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0]

    if (!file) {
      return
    }

    setFormData((prev) => ({
      ...prev,
      imageFile: file,
    }))

    const reader = new FileReader()

    reader.onloadend = () => {
      setImagePreview(reader.result as string)
    }

    reader.readAsDataURL(file)
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (!formData.prompt.trim()) {
        error('Please enter a prompt')
        return
      }

      if (!user?.uid) {
        error('You must be logged in to generate videos')
        return
      }

      if ((profile?.credits || 0) < creditCost) {
        error(`Insufficient credits. You need ${creditCost} credits.`)
        return
      }

      if (!primaryGenerator?.enabled) {
        error(
          'Video generator currently unavailable. Please try again later.'
        )
        return
      }

      const formDataToSend = new FormData()

      formDataToSend.append('prompt', formData.prompt)
      formDataToSend.append('duration', formData.duration)
      formDataToSend.append('style', formData.style)
      formDataToSend.append('genre', formData.genre)
      formDataToSend.append('voiceGender', formData.voiceGender)
      formDataToSend.append(
        'includeMusic',
        String(formData.includeMusic)
      )
      formDataToSend.append(
        'includeLaughter',
        String(formData.includeLaughter)
      )
      formDataToSend.append('creditCost', String(creditCost))
      formDataToSend.append('userId', user.uid)

      if (formData.imageFile) {
        formDataToSend.append('image', formData.imageFile)
      }

      const res = await fetch('/api/generate', {
        method: 'POST',
        body: formDataToSend,
      })

      const result = await res.json()

      if (!res.ok) {
        throw new Error(
          result.error || 'Failed to generate video'
        )
      }

      const videoId =
        result.videoId ||
        result.id ||
        `video-${Date.now()}`

      if (!result.videoUrl) {
        throw new Error('Video URL was not returned by the API')
      }

      setGeneratedVideo({
        id: videoId,
        url: result.videoUrl,
      })

      success(
        `Video generated! Credits remaining: ${
          result.remainingCredits ?? 'updated'
        }`
      )

      setFormData({
        prompt: '',
        duration: '30',
        style: 'realistic',
        genre: 'commercial',
        voiceGender: 'male',
        includeMusic: true,
        includeLaughter: false,
        imageFile: null,
      })

      setImagePreview(null)
    } catch (err) {
      console.error('Video generation error:', err)

      error(
        err instanceof Error
          ? err.message
          : 'Failed to generate video. Please try again.'
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link
            href="/dashboard"
            className="flex items-center gap-2 text-primary hover:text-primary/80"
          >
            <ArrowLeft className="h-5 w-5" />
            Back to Dashboard
          </Link>

          <span className="text-sm text-muted-foreground">
            Credits: {profile?.credits?.toLocaleString() || 0}
          </span>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Create Human Actor Video
          </h1>

          <p className="text-lg text-muted-foreground">
            Generate professional videos featuring human actors in any
            style or genre
          </p>
        </div>

        {generatedVideo && (
          <div className="mb-12 p-8 bg-card border border-border rounded-lg">
            <h2 className="text-2xl font-bold text-foreground mb-6">
              Your Generated Video
            </h2>

            <VideoPlayer
              videoUrl={generatedVideo.url}
              videoId={generatedVideo.id}
              onRegenerate={() => setGeneratedVideo(null)}
              onDownload={async () => {
                success('Video downloaded')
              }}
              userRole={profile?.role || 'user'}
              subscriptionPlan={
                profile?.subscriptionPlan || 'free'
              }
            />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <form
            onSubmit={handleSubmit}
            className="lg:col-span-2 space-y-6"
          >
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Describe your video scene
              </label>

              <textarea
                name="prompt"
                value={formData.prompt}
                onChange={handleInputChange}
                placeholder="e.g., A professional woman in an office presenting a product, speaking confidently about its benefits..."
                className="w-full px-4 py-3 bg-card border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                rows={4}
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Upload Reference Image (Optional)
              </label>

              <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary transition-colors">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="imageUpload"
                  disabled={loading}
                />

                <label
                  htmlFor="imageUpload"
                  className="cursor-pointer flex flex-col items-center gap-2"
                >
                  <Upload className="h-8 w-8 text-muted-foreground" />

                  <span className="text-sm text-foreground">
                    Click to upload or drag and drop
                  </span>

                  <span className="text-xs text-muted-foreground">
                    PNG, JPG, GIF up to 10MB
                  </span>
                </label>
              </div>

              {imagePreview && (
                <div className="mt-4">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="h-32 w-32 rounded-lg object-cover mx-auto border border-border"
                  />
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Video Style
                </label>

                <select
                  name="style"
                  value={formData.style}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-card border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  disabled={loading}
                >
                  <option value="realistic">Realistic</option>
                  <option value="animated">Animated</option>
                  <option value="cartoon">Cartoon</option>
                  <option value="3d">3D</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Genre
                </label>

                <select
                  name="genre"
                  value={formData.genre}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-card border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  disabled={loading}
                >
                  <option value="commercial">Commercial</option>
                  <option value="educational">Educational</option>
                  <option value="promotional">Promotional</option>
                  <option value="testimonial">Testimonial</option>
                  <option value="entertainment">
                    Entertainment
                  </option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Duration (seconds)
                </label>

                <select
                  name="duration"
                  value={formData.duration}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-card border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  disabled={loading}
                >
                  <option value="15">15 seconds</option>
                  <option value="30">30 seconds</option>
                  <option value="60">60 seconds</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Voice Gender
                </label>

                <select
                  name="voiceGender"
                  value={formData.voiceGender}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 bg-card border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  disabled={loading}
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="neutral">Neutral</option>
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="includeMusic"
                  checked={formData.includeMusic}
                  onChange={handleInputChange}
                  disabled={loading}
                  className="w-4 h-4 rounded"
                />

                <span className="text-sm text-foreground">
                  Include Background Music
                </span>
              </label>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="includeLaughter"
                  checked={formData.includeLaughter}
                  onChange={handleInputChange}
                  disabled={loading}
                  className="w-4 h-4 rounded"
                />

                <span className="text-sm text-foreground">
                  Include Sound Effects
                </span>
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
            >
              {loading && (
                <Loader2 className="h-5 w-5 animate-spin" />
              )}

              {loading ? 'Generating...' : 'Generate Video'}
            </button>
          </form>

          <div className="lg:col-span-1">
            <div className="bg-card border border-border rounded-lg p-6 space-y-6">
              <div>
                <h3 className="font-semibold text-foreground mb-2">
                  Video Details
                </h3>

                <div className="space-y-2 text-sm">
                  <p>
                    <span className="text-muted-foreground">
                      Description:
                    </span>{' '}
                    <span className="font-medium text-foreground">
                      {formData.prompt
                        ? `${formData.prompt.substring(0, 50)}...`
                        : 'Not set'}
                    </span>
                  </p>

                  <p>
                    <span className="text-muted-foreground">
                      Duration:
                    </span>{' '}
                    <span className="font-medium text-foreground">
                      {formData.duration}s
                    </span>
                  </p>

                  <p>
                    <span className="text-muted-foreground">
                      Style:
                    </span>{' '}
                    <span className="font-medium text-foreground capitalize">
                      {formData.style}
                    </span>
                  </p>

                  <p>
                    <span className="text-muted-foreground">
                      Genre:
                    </span>{' '}
                    <span className="font-medium text-foreground capitalize">
                      {formData.genre}
                    </span>
                  </p>
                </div>
              </div>

              <div className="border-t border-border pt-6">
                <h3 className="font-semibold text-foreground mb-2">
                  Credit Cost
                </h3>

                <p className="text-2xl font-bold text-primary mb-4">
                  {creditCost} credits
                </p>

                <p className="text-sm text-muted-foreground">
                  Your current balance:{' '}
                  <span className="font-semibold">
                    {profile?.credits || 0}
                  </span>{' '}
                  credits
                </p>
              </div>

              <div className="border-t border-border pt-6">
                <h3 className="font-semibold text-foreground mb-2">
                  Features
                </h3>

                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ Professional actors</li>
                  <li>✓ Multiple scenes</li>
                  <li>✓ Natural lip sync</li>
                  <li>✓ Background music</li>
                  <li>✓ Custom subtitles</li>
                  <li>✓ Fast rendering</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default function HumanVideosPage() {
  return (
    <ProtectedRoute>
      <HumanVideosContent />
    </ProtectedRoute>
  )
}