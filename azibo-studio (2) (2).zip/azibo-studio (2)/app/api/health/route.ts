import { NextResponse } from 'next/server'
import { getClientEnv } from '@/lib/env'

export async function GET() {
  try {
    const clientEnv = getClientEnv()
    const hasFirebaseConfig =
      !!clientEnv.firebase.apiKey &&
      !!clientEnv.firebase.projectId &&
      !!clientEnv.firebase.authDomain

    return NextResponse.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      envs: {
        firebase: hasFirebaseConfig,
        paystack: !!clientEnv.paystack.publicKey,
      },
    })
  } catch (error) {
    console.error('[v0] Health check error:', error)
    return NextResponse.json(
      {
        status: 'error',
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
