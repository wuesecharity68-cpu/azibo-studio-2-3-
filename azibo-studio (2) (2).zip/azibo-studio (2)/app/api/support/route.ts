import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'

const supportTicketSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  subject: z.string().min(5).max(200),
  message: z.string().min(10).max(5000),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const validation = supportTicketSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json(
        { error: 'Invalid form data', details: validation.error.errors },
        { status: 400 }
      )
    }

    const { name, email, subject, message } = validation.data

    // TODO: Save to Firestore support_tickets collection
    // const db = getAdminDb()
    // await db.collection('support_tickets').add({
    //   name,
    //   email,
    //   subject,
    //   message,
    //   status: 'open',
    //   createdAt: admin.firestore.FieldValue.serverTimestamp(),
    //   updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    // })

    // TODO: Send confirmation email to user
    // TODO: Send notification to admin

    console.log('[v0] Support ticket created:', {
      name,
      email,
      subject,
    })

    return NextResponse.json(
      { success: true, message: 'Support ticket created successfully' },
      { status: 201 }
    )
  } catch (error) {
    console.error('[v0] Support submission error:', error)
    return NextResponse.json(
      { error: 'Failed to submit support ticket' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Support ticket endpoint is running',
  })
}
