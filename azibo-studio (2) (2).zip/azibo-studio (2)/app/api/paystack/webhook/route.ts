import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'
import { FieldValue } from 'firebase-admin/firestore'
import { getAdminDb } from '@/lib/firebase-admin.server'

type PaystackMetadata = {
  userId?: string
  planId?: string
  billingPeriod?: string
  credits?: number
  amount?: number
}

type PaystackEvent = {
  event?: string
  data?: {
    reference?: string
    amount?: number
    status?: string
    customer?: {
      email?: string
    }
    metadata?: PaystackMetadata
  }
}

export async function POST(request: NextRequest) {
  try {
    const secretKey = process.env.PAYSTACK_SECRET_KEY

    if (!secretKey) {
      console.error('[AZIBO] PAYSTACK_SECRET_KEY is not configured')

      return NextResponse.json(
        { error: 'Webhook not configured' },
        { status: 500 }
      )
    }

    const body = await request.text()
    const signature = request.headers.get('x-paystack-signature')

    if (!signature) {
      return NextResponse.json(
        { error: 'Missing signature' },
        { status: 401 }
      )
    }

    const hash = crypto
      .createHmac('sha512', secretKey)
      .update(body)
      .digest('hex')

    if (
      hash.length !== signature.length ||
      !crypto.timingSafeEqual(
        Buffer.from(hash),
        Buffer.from(signature)
      )
    ) {
      console.error('[AZIBO] Invalid Paystack signature')

      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 401 }
      )
    }

    const event = JSON.parse(body) as PaystackEvent

    if (event.event !== 'charge.success') {
      return NextResponse.json({
        success: true,
        message: 'Event received',
      })
    }

    const payment = event.data

    if (!payment) {
      return NextResponse.json(
        { error: 'Missing payment data' },
        { status: 400 }
      )
    }

    if (payment.status !== 'success') {
      return NextResponse.json({
        success: true,
        message: 'Payment was not successful',
      })
    }

    const reference = payment.reference

    if (!reference) {
      return NextResponse.json(
        { error: 'Missing payment reference' },
        { status: 400 }
      )
    }

    const metadata = payment.metadata

    if (!metadata?.userId || !metadata.planId) {
      console.error('[AZIBO] Missing payment metadata')

      return NextResponse.json(
        { error: 'Missing payment metadata' },
        { status: 400 }
      )
    }

    const credits = Number(metadata.credits)

    if (!Number.isFinite(credits) || credits <= 0) {
      return NextResponse.json(
        { error: 'Invalid credit amount' },
        { status: 400 }
      )
    }

    const db = getAdminDb()

    const userRef = db.collection('users').doc(metadata.userId)
    const paymentRef = db.collection('payments').doc(reference)

    const existingPayment = await paymentRef.get()

    if (existingPayment.exists) {
      return NextResponse.json({
        success: true,
        message: 'Payment already processed',
        reference,
      })
    }

    const userSnapshot = await userRef.get()

    if (!userSnapshot.exists) {
      console.error(
        '[AZIBO] User not found:',
        metadata.userId
      )

      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const userData = userSnapshot.data() ?? {}

    const currentCredits =
      typeof userData.credits === 'number'
        ? userData.credits
        : 0

    const newBalance = currentCredits + credits

    const subscriptionPlan =
      metadata.planId === 'professional'
        ? 'pro'
        : metadata.planId

    const batch = db.batch()

    batch.update(userRef, {
      credits: newBalance,
      subscriptionPlan,
      updatedAt: FieldValue.serverTimestamp(),
    })

    batch.set(paymentRef, {
      reference,
      userId: metadata.userId,
      email: payment.customer?.email ?? null,
      amount: payment.amount ?? null,
      planId: metadata.planId,
      billingPeriod: metadata.billingPeriod ?? null,
      credits,
      status: 'success',
      createdAt: FieldValue.serverTimestamp(),
    })

    const creditLogRef = userRef
      .collection('creditTransactions')
      .doc()

    batch.set(creditLogRef, {
      userId: metadata.userId,
      amount: credits,
      type: 'purchase',
      description: `${metadata.planId} ${metadata.billingPeriod ?? ''} subscription`,
      reference,
      createdAt: FieldValue.serverTimestamp(),
    })

    await batch.commit()

    console.log('[AZIBO] Payment processed successfully:', {
      reference,
      userId: metadata.userId,
      planId: metadata.planId,
      credits,
      newBalance,
    })

    return NextResponse.json({
      success: true,
      reference,
      credits,
      newBalance,
      message: 'Payment processed successfully',
    })
  } catch (error: unknown) {
    console.error('[AZIBO] Webhook error:', error)

    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Paystack webhook endpoint is running',
  })
}